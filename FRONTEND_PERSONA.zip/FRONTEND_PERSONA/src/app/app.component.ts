import { Component, OnInit} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Observable } from 'rxjs';
import {CiudadesService} from './services/Ciudades/ciudades.service';
import { PersonasService } from './services/Personas/personas.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit{

  personaForm!: FormGroup;
  ciudades: any;
  personas: any;
  

  constructor( 
    public fb: FormBuilder,
    public ciudadesService: CiudadesService,
    public personasService: PersonasService
    ){


    }

  ngOnInit(): void {

    this.personaForm = this.fb.group({
    id:[''],
    nombre : ['', Validators.required],
		apellido : ['', Validators.required],
		documento : ['', Validators.required],
		edad : ['', Validators.required],
		email : ['', Validators.required],
		telefono : ['', Validators.required],
		usuario : ['', Validators.required],
		password : ['', Validators.required],
		ciudad : ['', Validators.required],
  });;

  this.ciudadesService.getAllCiudades().subscribe(resp => {
    this.ciudades = resp; 
  },
   error => {console.error(error)}
  );

 }


  guardar():void {
    this.personasService.savePersona(this.personaForm.value).subscribe( resp => {
      this.personaForm.reset();
      this.personas = this.personas.filter((persona: { id: any; }) =>resp.id!=persona.id);
      this.personas.push(resp);

    },
      error => { console.error(error) }
  )
  
  this.personasService.getAllPersonas().subscribe(resp=>{
    this.personas = resp;
  },
    error => {console.error(error)}
  );

  }

  eliminar(persona: { id: string; }){
    this.personasService.deletePersona(persona.id).subscribe(resp =>{
      if(resp == true){
        this.personas.pop(persona)
      }
    })
  }

  editar(persona: { id: any; nombre: any; apellido: any; documento: any; edad: any; email: any; telefono: any; usuario: any; password: any; ciudad: any; }){
    this.personaForm.setValue({
      id:persona.id,
      nombre : persona.nombre,
      apellido : persona.apellido,
      documento : persona.documento,
      edad : persona.edad,
      email : persona.email,
      telefono : persona.telefono,
      usuario : persona.usuario,
      password : persona.password,
      ciudad : persona.ciudad
    })
  }

}

